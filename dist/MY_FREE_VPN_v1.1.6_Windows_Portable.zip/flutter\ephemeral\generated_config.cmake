# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\src\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\mehboob.rehman\\OneDrive - National Foods Limited\\AI\\autodesk\\Autodeskprojects\\my-free-vpn\\client" PROJECT_DIR)

set(FLUTTER_VERSION "1.1.6+7" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 6 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 7 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\src\\flutter"
  "PROJECT_DIR=C:\\Users\\mehboob.rehman\\OneDrive - National Foods Limited\\AI\\autodesk\\Autodeskprojects\\my-free-vpn\\client"
  "FLUTTER_ROOT=C:\\src\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\mehboob.rehman\\OneDrive - National Foods Limited\\AI\\autodesk\\Autodeskprojects\\my-free-vpn\\client\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\mehboob.rehman\\OneDrive - National Foods Limited\\AI\\autodesk\\Autodeskprojects\\my-free-vpn\\client"
  "FLUTTER_TARGET=lib\\main.dart"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=true"
  "PACKAGE_CONFIG=C:\\Users\\mehboob.rehman\\OneDrive - National Foods Limited\\AI\\autodesk\\Autodeskprojects\\my-free-vpn\\client\\.dart_tool\\package_config.json"
)
