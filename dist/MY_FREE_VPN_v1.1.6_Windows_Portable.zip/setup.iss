Dummy Inno Setup script
